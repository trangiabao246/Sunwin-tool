
        import { initializeApp } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-app.js";
        import { getDatabase, ref, get } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-database.js";

        const firebaseConfig = {
            apiKey: "AIzaSyCXWqunKdVeqO7X4F_u98GEUp70u4vJXnE",
            authDomain: "tool-web-fda89.firebaseapp.com",
            databaseURL: "https://tool-web-fda89-default-rtdb.firebaseio.com",
            projectId: "tool-web-fda89",
            storageBucket: "tool-web-fda89.appspot.com",
            messagingSenderId: "825298469640",
            appId: "1:825298469640:web:ba74868ccfc01e0489a2bd",
            measurementId: "G-MHJP0HN014"
        };

        const app = initializeApp(firebaseConfig);
        const database = getDatabase(app);

        async function verifyKey(key) {
            const usersRef = ref(database, "users");
            try {
                const snapshot = await get(usersRef);
                if (snapshot.exists()) {
                    const users = snapshot.val();
                    for (const userId in users) {
                        if (users[userId].key === key) {
                            console.log("✅ Key hợp lệ:", users[userId]);
                            return true;
                        }
                    }
                }
                console.log("❌ Key không tồn tại!");
                return false;
            } catch (error) {
                console.error("🔥 Lỗi khi lấy dữ liệu Firebase:", error);
                return false;
            }
        }

        document.addEventListener("DOMContentLoaded", function () {
    // Xử lý đăng nhập
    document.getElementById('login-form').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const webgameLink = document.getElementById('webgame-link').value.trim();
        const userKey = document.getElementById('software-key').value.trim();
        const linkError = document.getElementById('link-error');
        const keyError = document.getElementById('key-error');

        linkError.style.display = 'none';
        keyError.style.display = 'none';

        if (!webgameLink) {
            linkError.style.display = 'block';
            return;
        }

        if (!userKey) {
            keyError.textContent = "Vui lòng nhập mã key.";
            keyError.style.display = 'block';
            return;
        }

        const isValidKey = await verifyKey(userKey);

        if (!isValidKey) {
            keyError.textContent = "Mã key không hợp lệ!";
            keyError.style.display = 'block';
            return;
        }

        localStorage.setItem('software-key', userKey);
        openGame(webgameLink);
    });

    function closeFloatingWindow() {
        document.getElementById('floating-window').style.display = 'none';
    }

    function chooseOption(option) {
        console.log('Bạn đã chọn:', option);
    }

    // Kéo thả cửa sổ nổi
// Kéo thả cửa sổ nổi
const floatingWindow = document.getElementById('floating-window');

let isDragging = false;
let offsetX = 0, offsetY = 0;


// Xử lý bắt đầu kéo (Hỗ trợ cả chuột và cảm ứng)
function startDrag(e) {
    isDragging = true;
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;

    offsetX = clientX - floatingWindow.getBoundingClientRect().left;
    offsetY = clientY - floatingWindow.getBoundingClientRect().top;
    floatingWindow.style.cursor = 'grabbing';
}

// Xử lý di chuyển (Hỗ trợ cả chuột và cảm ứng)
function onDrag(e) {
    if (!isDragging) return;
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;

    const newX = clientX - offsetX;
    const newY = clientY - offsetY;

    floatingWindow.style.left = `${newX}px`;
    floatingWindow.style.top = `${newY}px`;
}

// Kết thúc kéo (Hỗ trợ cả chuột và cảm ứng)
function endDrag() {
    isDragging = false;
    floatingWindow.style.cursor = 'grab';
}

// Gán sự kiện cho cả chuột và cảm ứng
floatingWindow.addEventListener('mousedown', startDrag);
floatingWindow.addEventListener('touchstart', startDrag);

document.addEventListener('mousemove', onDrag);
document.addEventListener('touchmove', onDrag);

document.addEventListener('mouseup', endDrag);
document.addEventListener('touchend', endDrag);




    // Định nghĩa hàm đóng cửa sổ
    window.closeFloatingWindow = function () {
        document.getElementById('floating-window').style.display = 'none';
    };

    // Tự động mở sau 3 giây (test)
    setTimeout(() => {
        document.getElementById('floating-window').style.display = 'block';
    }, 3000);
});


        window.openGame = function (url) {
            document.querySelector('.login-box').style.display = 'none';
            document.getElementById('game-container').style.display = 'block';
            document.getElementById('game-frame').src = url;
        };

        window.exitGame = function () {
            document.getElementById('game-container').style.display = 'none';
            document.querySelector('.login-box').style.display = 'block';
        };

        document.getElementById('game-frame').onload = function () {
            console.log("Game đã load, chờ nhấn 'Bắt đầu' để dự đoán...");
    };

        function showFloatingWindow() {
    document.getElementById('floating-window').style.display = 'block';
}

function closeFloatingWindow() {
    document.getElementById('floating-window').style.display = 'none';
}

window.onload = function () {
    console.log("Script đã tải, sẵn sàng bắt đầu dự đoán!");
    
    document.getElementById('game-frame').onload = function () {
        console.log("Game đã load, chờ nhấn 'Bắt đầu' để dự đoán...");
    };

    window.startPrediction = function () {
        document.getElementById('game-container').style.display = 'block';
        document.querySelector('.login-box').style.display = 'none';
        console.log("Bắt đầu dự đoán ngay lập tức...");
        startCycle();
    };
};



let lastPrediction = null;
function randomPrediction() {
    return Math.random() < 0.5 ? 'tai' : 'xiu';
}

function blinkButton(buttonId, duration, callback) {
    const button = document.getElementById(buttonId);
    if (!button) {
        console.error('Không tìm thấy nút:', buttonId);
        return;
    }

    // Tắt nháy đèn bên còn lại trước khi bắt đầu
    document.getElementById('btn-tai').style.visibility = 'visible';
    document.getElementById('btn-xiu').style.visibility = 'visible';

    let isVisible = true;
    const interval = setInterval(() => {
        button.style.visibility = isVisible ? 'hidden' : 'visible';
        isVisible = !isVisible;
    }, 300);

    setTimeout(() => {
        clearInterval(interval);
        button.style.visibility = 'visible';
        console.log('Đã dừng nhấp nháy, chờ 13 giây...');
        setTimeout(callback, 18000);
    }, duration);
}

function startCycle() {
    console.log('Chờ 10 giây để phân tích...');

    setTimeout(() => {
        const prediction = randomPrediction();
        const buttonId = prediction === 'tai' ? 'btn-tai' : 'btn-xiu';
        console.log('Dự đoán:', prediction);
        lastPrediction = prediction;

        blinkButton(buttonId, 40000, startCycle);
    }, 10000);
}
const canvas = document.getElementById("matrixCanvas");
const ctx = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
const fontSize = 16;
const columns = Math.floor(canvas.width / fontSize);
const drops = new Array(columns).fill(0);

function drawMatrix() {
    ctx.fillStyle = "rgba(0, 0, 0, 0.05)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "#0F0";
    ctx.font = `${fontSize}px monospace`;

    for (let i = 0; i < drops.length; i++) {
        const text = letters.charAt(Math.floor(Math.random() * letters.length));
        ctx.fillText(text, i * fontSize, drops[i] * fontSize);

        if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
            drops[i] = 0;
        }
        drops[i]++;
    }
}

setInterval(drawMatrix, 50);

window.addEventListener("resize", () => {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
});
